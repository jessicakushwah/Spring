package com.example;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.model.ReportCard;
import com.example.model.Student;
import com.example.util.HibernateUtil;

public class App {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Session session = HibernateUtil.getSessionFactory().openSession();

        Transaction tx = session.beginTransaction();

        System.out.println("Enter student name");

        String name = sc.nextLine();

        System.out.println("Enter student marks");

        double marks = sc.nextDouble();

        Student s = new Student(name);

        ReportCard rc = new ReportCard(marks);

        s.setReportcard(rc);

        session.persist(s);

        tx.commit();

        System.out.println("Transaction Committed");

        Student s2 = session.get(Student.class, s.getId());

        System.out.println("Student details are below : " + s2);

        ReportCard rc1 = session.get(ReportCard.class, rc.getId());

        System.out.println("Report Card Details : " + rc1);

        System.out.println("Student details via Report Card : " + s2.getName());

        session.close();
        HibernateUtil.close();
        sc.close();
    }
}