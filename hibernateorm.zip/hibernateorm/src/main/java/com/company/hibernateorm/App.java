package com.company.hibernateorm;

import com.company.hibernateorm.model.Student;
import com.company.hibernateorm.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Session session =
                HibernateUtil.getSessionFactory().openSession();

        Transaction tx = session.beginTransaction();

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Student Name:");
        String name = sc.nextLine();

        System.out.println("Enter Student Email:");
        String email = sc.nextLine();

        System.out.println("Enter Student Course:");
        String course = sc.nextLine();

        Student s1 = new Student(name, email, course);

        session.persist(s1);

        tx.commit();

        System.out.println("Data Inserted Successfully");
        System.out.println(s1);

        session.close();
    }
}