<%@ taglib uri="http://java.sun.com/jsp/jstl/core"
           prefix="c" %>

<html>
<head>
    <title>LMS</title>
</head>

<body>

<h2>LMS Admin Panel</h2>

<a href="student-form">Add Student</a>

|

<a href="course-form">Add Course</a>

|

<a href="enroll-form">Enroll Student</a>

<br><br>

<table border="1"
       cellpadding="10">

    <tr>

        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Courses</th>

    </tr>

    <c:forEach var="student"
               items="${students}">

        <tr>

            <td>${student.id}</td>

            <td>${student.name}</td>

            <td>${student.email}</td>

            <td>

                <c:forEach var="course"
                           items="${student.courses}">

                    ${course.courseName}

                    <br>

                </c:forEach>

            </td>

        </tr>

    </c:forEach>

</table>

</body>
</html>