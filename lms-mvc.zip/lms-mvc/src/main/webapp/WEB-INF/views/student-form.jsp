<%@ taglib uri="http://www.springframework.org/tags/form"
           prefix="form" %>

<html>
<head>
    <title>Add Student</title>
</head>

<body>

<h2>Add Student</h2>

<form:form action="save-student"
           method="post"
           modelAttribute="student">

    Name:
    <form:input path="name"/>

    <br><br>

    Email:
    <form:input path="email"/>

    <br><br>

    <input type="submit"
           value="Save Student"/>

</form:form>

<br>

<a href="view">View</a>

</body>
</html>