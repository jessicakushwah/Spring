<%@ taglib uri="http://java.sun.com/jsp/jstl/core"
           prefix="c" %>

<html>
<head>
    <title>Enroll Student</title>
</head>

<body>

<h2>Enroll Student</h2>

<form action="enroll"
      method="post">

    Select Student:

    <select name="studentId">

        <c:forEach var="student"
                   items="${students}">

            <option value="${student.id}">
                    ${student.name}
            </option>

        </c:forEach>

    </select>

    <br><br>

    Select Courses:

    <br>

    <c:forEach var="course"
               items="${courses}">

        <input type="checkbox"
               name="courseIds"
               value="${course.id}"/>

        ${course.courseName}

        <br>

    </c:forEach>

    <br>

    <input type="submit"
           value="Enroll"/>

</form>

<br>

<a href="view">View</a>

</body>
</html>