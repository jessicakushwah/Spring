<%@ taglib uri="http://www.springframework.org/tags/form"
           prefix="form" %>

<html>
<head>
    <title>Add Course</title>
</head>

<body>

<h2>Add Course</h2>

<form:form action="save-course"
           method="post"
           modelAttribute="course">

    Course Name:
    <form:input path="courseName"/>

    <br><br>

    Duration:
    <form:input path="duration"/>

    <br><br>

    <input type="submit"
           value="Save Course"/>

</form:form>

<br>

<a href="view">View</a>

</body>
</html>