package com.lms.dao;

import com.lms.config.HibernateUtil;
import com.lms.entity.Course;
import com.lms.entity.Student;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentDao {

    public void saveStudent(Student student) {

        Session session =
                HibernateUtil.getSessionFactory().openSession();

        Transaction tx =
                session.beginTransaction();

        session.save(student);

        tx.commit();

        session.close();
    }

    public List<Student> getAllStudents() {

        Session session =
                HibernateUtil.getSessionFactory().openSession();

        List<Student> students =
                session.createQuery("from Student",
                        Student.class).list();

        session.close();

        return students;
    }

    public void enrollStudent(
            int studentId,
            List<Integer> courseIds
    ) {

        Session session =
                HibernateUtil.getSessionFactory().openSession();

        Transaction tx =
                session.beginTransaction();

        Student student =
                session.get(Student.class,
                        studentId);

        student.getCourses().clear();

        for (Integer courseId : courseIds) {

            Course course =
                    session.get(Course.class,
                            courseId);

            student.getCourses().add(course);
        }

        session.update(student);

        tx.commit();

        session.close();
    }
}