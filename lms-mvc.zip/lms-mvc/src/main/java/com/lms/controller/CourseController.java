package com.lms.controller;

import com.lms.entity.Course;
import com.lms.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CourseController {

    @Autowired
    private CourseService courseService;

    @GetMapping("/course-form")
    public String courseForm(Model model) {

        model.addAttribute(
                "course",
                new Course()
        );

        return "course-form";
    }

    @PostMapping("/save-course")
    public String saveCourse(
            @ModelAttribute("course")
            Course course
    ) {

        courseService.saveCourse(course);

        return "redirect:/view";
    }
}