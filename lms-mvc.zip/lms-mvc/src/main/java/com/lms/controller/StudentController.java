package com.lms.controller;

import com.lms.entity.Student;
import com.lms.service.CourseService;
import com.lms.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService;

    @GetMapping("/")
    public String home(Model model) {

        model.addAttribute(
                "students",
                studentService.getAllStudents()
        );

        return "view";
    }

    @GetMapping("/student-form")
    public String studentForm(Model model) {

        model.addAttribute(
                "student",
                new Student()
        );

        return "student-form";
    }

    @PostMapping("/save-student")
    public String saveStudent(
            @ModelAttribute("student")
            Student student
    ) {

        studentService.saveStudent(student);

        return "redirect:/view";
    }

    @GetMapping("/enroll-form")
    public String enrollForm(Model model) {

        model.addAttribute(
                "students",
                studentService.getAllStudents()
        );

        model.addAttribute(
                "courses",
                courseService.getAllCourses()
        );

        return "enroll-form";
    }

    @PostMapping("/enroll")
    public String enrollStudent(

            @RequestParam("studentId")
            int studentId,

            @RequestParam("courseIds")
            List<Integer> courseIds
    ) {

        studentService.enrollStudent(
                studentId,
                courseIds
        );

        return "redirect:/view";
    }

    @GetMapping("/view")
    public String view(Model model) {

        model.addAttribute(
                "students",
                studentService.getAllStudents()
        );

        return "view";
    }
}