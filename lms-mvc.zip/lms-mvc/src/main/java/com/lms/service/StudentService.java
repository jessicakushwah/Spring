package com.lms.service;

import com.lms.dao.StudentDao;
import com.lms.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentDao studentDao;

    public void saveStudent(Student student) {
        studentDao.saveStudent(student);
    }

    public List<Student> getAllStudents() {
        return studentDao.getAllStudents();
    }

    public void enrollStudent(
            int studentId,
            List<Integer> courseIds
    ) {

        studentDao.enrollStudent(
                studentId,
                courseIds
        );
    }
}