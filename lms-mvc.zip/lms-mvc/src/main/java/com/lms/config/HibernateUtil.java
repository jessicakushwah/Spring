package com.lms.config;

import com.lms.entity.Course;
import com.lms.entity.Student;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {

        if (sessionFactory == null) {

            Configuration config = new Configuration();

            config.setProperty(
                    "hibernate.connection.driver_class",
                    "com.mysql.cj.jdbc.Driver"
            );

            config.setProperty(
                    "hibernate.connection.url",
                    "jdbc:mysql://localhost:3306/lmsdb"
            );

            config.setProperty(
                    "hibernate.connection.username",
                    "root"
            );

            config.setProperty(
                    "hibernate.connection.password",
                    "1234"
            );

            config.setProperty(
                    "hibernate.dialect",
                    "org.hibernate.dialect.MySQL8Dialect"
            );

            config.setProperty(
                    "hibernate.hbm2ddl.auto",
                    "update"
            );

            config.setProperty(
                    "hibernate.show_sql",
                    "true"
            );

            config.addAnnotatedClass(Student.class);
            config.addAnnotatedClass(Course.class);

            sessionFactory = config.buildSessionFactory();
        }

        return sessionFactory;
    }
}